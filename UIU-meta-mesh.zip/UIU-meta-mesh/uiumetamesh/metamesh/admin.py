from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(students)
admin.site.register(posts)
admin.site.register(likes)
admin.site.register(notification)
admin.site.register(clubs)
admin.site.register(clubApproval)
admin.site.register(clubpost)
admin.site.register(clublikes)
admin.site.register(eevent)
admin.site.register(conversations)
admin.site.register(messages)
