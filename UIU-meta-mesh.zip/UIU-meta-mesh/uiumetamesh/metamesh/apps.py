from django.apps import AppConfig


class MetameshConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'metamesh'
